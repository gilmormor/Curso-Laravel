$('.menu_rol').on('change', function () {
    var data = {
        menu_id: $(this).data('menuid'),
        rol_id: $(this).val(),
        _token: $('input[name=_token]').val()
    };
    if ($(this).is(':checked')) {
        data.estado = 1
    } else {
        data.estado = 0
    }
    ajaxRequest('/admin/menu-rol', data);
});

function ajaxRequest (url, data) {
    $.ajax({
        url: url,
        type: 'POST',
        data: data,
        success: function (respuesta) {
            tipoMensaje = 'warning';
            if(data.estado == 1){
                tipoMensaje = 'success';
            }
            Biblioteca.notificaciones(respuesta.respuesta, 'Plastiservi', tipoMensaje);
        }
    });
} 
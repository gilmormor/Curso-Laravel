<?php if(session("mensaje")): ?>
    <div class="alert alert-success alert-dismissible" data-auto-dismiss="3000">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        <h4><i class="icon fa fa-check"></i> Mensaje Sistema!</h4>
        <ul>
            <li><?php echo e(session("mensaje")); ?></li>
        </ul>
    </div>
<?php endif; ?><?php /**PATH C:\laragon\www\biblioteca\resources\views/includes/mensaje.blade.php ENDPATH**/ ?>
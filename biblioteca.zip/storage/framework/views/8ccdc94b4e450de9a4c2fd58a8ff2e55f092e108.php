<?php if($item["submenu"] == []): ?>
    <li class="<?php echo e(getMenuActivo($item["url"])); ?>">
        <a href="<?php echo e(url($item['url'])); ?>">
          <i class="fa <?php echo e($item["icono"]); ?>"></i> <span><?php echo e($item["nombre"]); ?></span>
        </a>
    </li>
<?php else: ?>
    <li class="treeview">
        <a href="javascript:;">
          <i class="fa <?php echo e($item["icono"]); ?>"></i> <span><?php echo e($item["nombre"]); ?></span>
          <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
          </span>
        </a>
        <ul class="treeview-menu">
            <?php $__currentLoopData = $item["submenu"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make("theme.$theme.menu-item", ["item" => $submenu], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </li>
<?php endif; ?><?php /**PATH C:\laragon\www\biblioteca\resources\views/theme/lte/menu-item.blade.php ENDPATH**/ ?>
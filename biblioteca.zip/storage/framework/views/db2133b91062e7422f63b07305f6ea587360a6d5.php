<?php $__env->startSection('titulo'); ?>
    Permiso
<?php $__env->stopSection(); ?>

<?php $__env->startSection("scripts"); ?>
    <script src="<?php echo e(asset("assets/pages/scripts/admin/permiso/crear.js")); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
<div class="row">
    <div class="col-lg-12">
        <?php echo $__env->make('includes.form-error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('includes.mensaje', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="box box-danger">
            <div class="box-header with-border">
                <h3 class="box-title">Crear Permiso</h3>
                <div class="box-tools pull-right">
                    <a href="<?php echo e(route('permiso')); ?>" class="btn btn-block btn-info btn-sm">
                        <i class="fa fa-fw fa-reply-all"></i> Volver al listado
                    </a>
                </div>
            </div>
            <form action="<?php echo e(route('guardar_permiso')); ?>" id="form-general" class="form-horizontal" method="POST" autocomplete="off">
                <?php echo csrf_field(); ?>
                <div class="box-body">
                    <?php echo $__env->make('admin.permiso.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="box-footer">
                    <div class="col-lg-3"></div>
                    <div class="col-lg-6">
                        <?php echo $__env->make('includes.boton-form-crear', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make("theme.$theme.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\biblioteca\resources\views/admin/permiso/crear.blade.php ENDPATH**/ ?>
<?php $__env->startSection('titulo'); ?>
    Plastiservi
<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.mensaje', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make("theme.$theme.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\biblioteca\resources\views/inicio.blade.php ENDPATH**/ ?>
Sistema de permisos <?php echo e($nombre); ?> <?php echo e($slug); ?>

<br>
<a href="<?php echo e(url('admin/sistema/permiso')); ?>">Ir a permiso -> url('admin/sistema/permiso')</a>
<br>
<a href="<?php echo e(route('permiso')); ?>">Ir a permiso -> route('permiso')</a><?php /**PATH C:\laragon\www\biblioteca\resources\views/permiso.blade.php ENDPATH**/ ?>
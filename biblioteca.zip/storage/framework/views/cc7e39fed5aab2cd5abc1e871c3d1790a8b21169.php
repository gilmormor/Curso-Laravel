<footer class="main-footer">
        <div class="pull-right hidden-xs">
          <b>Version</b> 2.0
        </div>
        <strong>Powered by Gilmer Moreno 2019 <a href="https://plastiservi.cl">Plastiservi</a>.</strong>
</footer><?php /**PATH C:\laragon\www\biblioteca\resources\views/theme/lte/footer.blade.php ENDPATH**/ ?>
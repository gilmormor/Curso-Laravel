<?php

namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Model;

class PermisoRol extends Model
{
    //
}

<button type="reset" class="btn btn-default">Cancel</button>
<button type="submit" class="btn btn-success">Actualizar</button>
<button type="reset" class="btn btn-default">Cancelar</button>
<button type="submit" class="btn btn-success">Guardar</button>
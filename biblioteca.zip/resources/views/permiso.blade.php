Sistema de permisos {{$nombre}} {{$slug}}
<br>
<a href="{{url('admin/sistema/permiso')}}">Ir a permiso -> url('admin/sistema/permiso')</a>
<br>
<a href="{{route('permiso')}}">Ir a permiso -> route('permiso')</a>
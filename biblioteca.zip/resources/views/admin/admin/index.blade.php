@extends("theme.$theme.layout")
@section('titulo')
    Menus    
@endsection

@section('contenido')
    <div class="col-lg-12">Bienvenidos</div>
@endsection

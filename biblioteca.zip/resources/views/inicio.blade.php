@extends("theme.$theme.layout")
@section('titulo')
    Plastiservi
@endsection
@include('includes.mensaje')